import json
import pymongo
import boto3
import base64
import wget
import hashlib
import os
from bson.json_util import dumps
import aws_encryption_sdk
from aws_encryption_sdk import CommitmentPolicy
 
 
#Get Secret manager secret names from environment variables
dbSecretName=os.environ.get("docdbCredentials")
keySecretName=os.environ.get("kms_key_alias")
#Download the Amazon DocumentDB Certificate Authority (CA) certificate required to authenticate to your cluster
wget.download('https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem', out='/tmp/rds-combined-ca-bundle.pem')

def decryptString(key_arn, ciphertext, botocore_session=None):
    # Set up an encryption client with an explicit commitment policy. If you do not explicitly choose a
    # commitment policy, REQUIRE_ENCRYPT_REQUIRE_DECRYPT is used by default.
    client = aws_encryption_sdk.EncryptionSDKClient(commitment_policy=CommitmentPolicy.REQUIRE_ENCRYPT_REQUIRE_DECRYPT)

    # Create an AWS KMS master key provider
    kms_kwargs = dict(key_ids=[key_arn])
    if botocore_session is not None:
        kms_kwargs["botocore_session"] = botocore_session
    master_key_provider = aws_encryption_sdk.StrictAwsKmsMasterKeyProvider(**kms_kwargs)
    
    # Decrypt the ciphertext
    cycled_plaintext, decrypted_header = client.decrypt(source=ciphertext, key_provider=master_key_provider)
    return cycled_plaintext
 
def lambda_handler(event, context):
    kmsclient = boto3.client('kms')
    #Get the kms key ARN from secret manager
    keyARN=json.loads(get_secret(keySecretName))['DocDBDemoKeyArn']
    #Get the DocumentDB credentials from SecretManager
    credentials=json.loads(get_secret(dbSecretName))
    username = credentials['username']
    password = credentials['password']
    clusterendpoint = credentials['host']+":"+str(credentials['port'])
    client = pymongo.MongoClient(clusterendpoint, username=username, password=password, tls='true', tlsCAFile='/tmp/rds-combined-ca-bundle.pem', retryWrites='false')
    print("connecting to database")
    db = client.sample_database
    profiledata = db['profiledata']
    insurancedata = db['insurancedata']
 
    #Find a person insurance document by personIdentifier
    searchPI=event['personIdentifier']
    hashedPI = hashlib.sha256(searchPI.encode()).hexdigest()
    query = {'hashedPI': hashedPI }
 
    pipeline = [{'$lookup':
                {'from' : 'insurancedata',
                 'localField' : 'hashedPI',
                 'foreignField' : 'hashedPI',
                 'as' : 'insuranceDetails'}},
 
            {'$match':
                 {'hashedPI' :hashedPI[:8]}},
                
             { '$project':
                 { "firstName": 1, "lastName": 1, "personIdentifier": 1, "insuranceDetails.policyName": 1, "insuranceDetails.startDate": 1 , "insuranceDetails.expDate": 1}}
             ]
    response=json.loads(dumps(profiledata.aggregate(pipeline)))
    #Since we are matching with truncated SHA, filter the exact match based on the PII
    matchedPII=None
    for resdata in response:
        d=resdata["personIdentifier"]['$binary']
        plaintext=base64.b64decode(decryptString(keyARN, bytes(base64.b64decode(d)))).decode()
        if plaintext == searchPI:
            resdata["personIdentifier"]=plaintext
            matchedPII=resdata
        
    #Clean up
    client.close()
    return {
        'statusCode': 200,
        'body': matchedPII
    }
   
 
def get_secret(secret_name):
    region_name = "us-east-1"
 
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    # We rethrow the exception by default.
 
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except Exception as e:
            raise e
 
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    return get_secret_value_response['SecretString']