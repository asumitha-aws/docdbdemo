import json
import pymongo
import boto3
import base64
import wget
import hashlib
import os
from bson.json_util import dumps
 
 
#Get Secret manager secret names from environment variables
dbSecretName=os.environ.get("docdbCredentials")
keySecretName=os.environ.get("kms_key_alias")
 
def lambda_handler(event, context):
    #Download the Amazon DocumentDB Certificate Authority (CA) certificate required to authenticate to your cluster
    wget.download('https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem', out='/tmp/rds-combined-ca-bundle.pem')
    kmsclient = boto3.client('kms')
    #Get the kms keyalias from secret manager
    keyAlias=json.loads(get_secret(keySecretName))
    keyId='alias/'+keyAlias['DocDBDemoKeyAlias']
    #Get the DocumentDB credentials from SecretManager
    credentials=json.loads(get_secret(dbSecretName))
    username = credentials['username']
    password = credentials['password']
    clusterendpoint = credentials['host']+":"+str(credentials['port'])
    client = pymongo.MongoClient(clusterendpoint, username=username, password=password, tls='true', tlsCAFile='/tmp/rds-combined-ca-bundle.pem', retryWrites='false')
    print("connecting to database")
    db = client.sample_database
    profiledata = db['profiledata']
    insurancedata = db['insurancedata']
 
    #Find a person insurance document by personIdentifier
    searchPI=event['personIdentifier']
    hashedPI = hashlib.sha256(searchPI.encode()).hexdigest()
    query = {'hashedPI': hashedPI }
 
    pipeline = [{'$lookup':
                {'from' : 'insurancedata',
                 'localField' : 'hashedPI',
                 'foreignField' : 'hashedPI',
                 'as' : 'insuranceDetails'}},
 
            {'$match':
                 {'hashedPI' :hashedPI}},
                
             { '$project':
                 { "firstName": 1, "lastName": 1, "personIdentifier": 1, "insuranceDetails.policyName": 1, "insuranceDetails.startDate": 1 , "insuranceDetails.expDate": 1}}
             ]
    response=json.loads(dumps(profiledata.aggregate(pipeline)))
    for resdata in response:
        d=resdata["personIdentifier"]['$binary']
        decryptedResponse=kmsclient.decrypt(CiphertextBlob=bytes(base64.b64decode(d)))
        resdata["personIdentifier"]=(base64.b64decode(decryptedResponse["Plaintext"]))
    #Clean up
    client.close()
    return {
        'statusCode': 200,
        'body': response
    }
   
 
def get_secret(secret_name):
    region_name = "us-east-1"
 
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
 
    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.
 
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except Exception as e:
            raise e
 
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    return get_secret_value_response['SecretString']