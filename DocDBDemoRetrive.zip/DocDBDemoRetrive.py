import json
import pymongo
import boto3
import base64
import wget
import hashlib
import os
from bson.json_util import dumps


#Get Amazon DocumentDB ceredentials from environment variables
username = os.environ.get("docdbUser")
password = os.environ.get("docdbPass")
clusterendpoint = os.environ.get("docdbEndpoint")
keyAlias=os.environ.get("kms_key_alias")

def lambda_handler(event, context):
    #Download the Amazon DocumentDB Certificate Authority (CA) certificate required to authenticate to your cluster
    wget.download('https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem', out='/tmp/rds-combined-ca-bundle.pem')
    kmsclient = boto3.client('kms')
    keyId='alias/'+keyAlias

    client = pymongo.MongoClient(clusterendpoint, username=username, password=password, tls='true', tlsCAFile='/tmp/rds-combined-ca-bundle.pem', retryWrites='false')
    print("connecting to database")
    db = client.sample_database
    profiledata = db['profiledata']
    insurancedata = db['insurancedata']

    #Find a person insurance document by ssn
    searchSSN=event['ssn']
    hashedSSN = hashlib.sha256(searchSSN.encode()).hexdigest()
    query = {'hashedSSN': hashedSSN }

    pipeline = [{'$lookup': 
                {'from' : 'insurancedata',
                 'localField' : 'hashedSSN',
                 'foreignField' : 'hashedSSN',
                 'as' : 'insuranceDetails'}},

             {'$match':
                 {'hashedSSN' :hashedSSN}},
                 
             { '$project': 
                 { "firstName": 1, "lastName": 1, "ssn": 1, "insuranceDetails.policyName": 1, "insuranceDetails.startDate": 1 , "insuranceDetails.expDate": 1}}
             ]
    response=json.loads(dumps(profiledata.aggregate(pipeline)))
    for resdata in response:
        d=resdata["ssn"]['$binary']
        decryptedResponse=kmsclient.decrypt(CiphertextBlob=bytes(base64.b64decode(d)))
        resdata["ssn"]=(base64.b64decode(decryptedResponse["Plaintext"]))
    #Clean up
    client.close()
    return {
        'statusCode': 200,
        'body': response
    }