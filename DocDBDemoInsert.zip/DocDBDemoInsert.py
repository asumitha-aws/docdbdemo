import json
import pymongo
import boto3
import base64
import wget
import hashlib
import os


#Insert sample data
PERSON_DATA = [
{ "_id" : 1, "firstName" : "Jayden", "lastName": "Barton", "ssn": "111-11-1111"},
{ "_id" : 2, "firstName" : "Aracely", "lastName": "Best",  "ssn": "222-22-2222"},
{ "_id" : 3, "firstName" : "Walter", "lastName": "Ashley", "ssn": "333-33-3333"},
{ "_id" : 4, "firstName" : "Macie", "lastName": "Cummings", "ssn": "444-44-4444"}
]


INSURANCE_DATA = [
{ "_id" : 1, "policyName" : "Ray Health", "startDate": "01/01/2021","expDate": "01/01/2022", "ssn": "444-44-4444"},
{ "_id" : 2, "policyName" : "Admini Plus", "startDate": "01/05/2021", "expDate": "01/01/2022", "ssn": "111-11-1111"},
{ "_id" : 3, "policyName" : "Bio Life", "startDate": "03/06/2021", "expDate": "01/01/2022","ssn": "333-33-3333"},
{ "_id" : 4, "policyName" : "InsuTrust", "startDate": "02/18/2021", "expDate": "01/01/2022","ssn": "222-22-2222"}
]

#Get Amazon DocumentDB ceredentials from environment variables
username = os.environ.get("docdbUser")
password = os.environ.get("docdbPass")
clusterendpoint = os.environ.get("docdbEndpoint")
keyAlias=os.environ.get("kms_key_alias")

def lambda_handler(event, context):
    wget.download('https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem', out='/tmp/rds-combined-ca-bundle.pem')
    kmsclient = boto3.client('kms')
    keyId='alias/'+keyAlias
    person_data=json.loads(json.dumps(PERSON_DATA))

    for person in person_data:
        hashedSSN = hashlib.sha256(person["ssn"].encode()).hexdigest()
        encryptedResponse=kmsclient.encrypt(KeyId=keyId, Plaintext=base64.b64encode(bytes(person["ssn"], 'utf-8')))
        person["hashedSSN"]=hashedSSN
        person["ssn"]=encryptedResponse["CiphertextBlob"]


    insurance_data=json.loads(json.dumps(INSURANCE_DATA))

    for insurance in insurance_data:
        hashedSSN = hashlib.sha256(insurance["ssn"].encode()).hexdigest()
        encryptedResponse=kmsclient.encrypt(KeyId=keyId, Plaintext=base64.b64encode(bytes(insurance["ssn"], 'utf-8')))
        insurance["hashedSSN"]=hashedSSN
        insurance["ssn"]=encryptedResponse["CiphertextBlob"]

    client = pymongo.MongoClient(clusterendpoint, username=username, password=password, tls='true', tlsCAFile='/tmp/rds-combined-ca-bundle.pem', retryWrites='false')
    print("connecting to database")
    db = client.sample_database
    profiledata = db['profiledata']
    insurancedata = db['insurancedata']

        

    #Insert data
    profiledata.insert_many(person_data)
    insurancedata.insert_many(insurance_data)
    print("Successfully inserted data")
    #Clean up
    client.close()
    return {
        'statusCode': 200,
        'body': "Successfully inserted data"
    }
