import json
import pymongo
import boto3
import base64
import wget
import hashlib
import os
import aws_encryption_sdk
from aws_encryption_sdk import CommitmentPolicy


#Insert sample data
PERSON_DATA = [
{ "_id" : 1, "firstName" : "Jayden", "lastName": "Barton", "personIdentifier": "111-11-1111"},
{ "_id" : 2, "firstName" : "Aracely", "lastName": "Best",  "personIdentifier": "222-22-2222"},
{ "_id" : 3, "firstName" : "Walter", "lastName": "Ashley", "personIdentifier": "333-33-3333"},
{ "_id" : 4, "firstName" : "Macie", "lastName": "Cummings", "personIdentifier": "444-44-4444"}
]


INSURANCE_DATA = [
{ "_id" : 1, "policyName" : "Ray Health", "startDate": "01/01/2021","expDate": "01/01/2022", "personIdentifier": "444-44-4444"},
{ "_id" : 2, "policyName" : "Admini Plus", "startDate": "01/05/2021", "expDate": "01/01/2022", "personIdentifier": "111-11-1111"},
{ "_id" : 3, "policyName" : "Bio Life", "startDate": "03/06/2021", "expDate": "01/01/2022","personIdentifier": "333-33-3333"},
{ "_id" : 4, "policyName" : "InsuTrust", "startDate": "02/18/2021", "expDate": "01/01/2022","personIdentifier": "222-22-2222"}
]

#Get Secret manager secret names from environment variables
dbSecretName=os.environ.get("docdbCredentials")
keySecretName=os.environ.get("kms_key_alias")
#Download the Amazon DocumentDB Certificate Authority (CA) certificate required to authenticate to your cluster
wget.download('https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem', out='/tmp/rds-combined-ca-bundle.pem')

def encryptString(key_arn, source_plaintext, botocore_session=None):
    # Set up an encryption client with an explicit commitment policy. If you do not explicitly choose a
    # commitment policy, REQUIRE_ENCRYPT_REQUIRE_DECRYPT is used by default.
    client = aws_encryption_sdk.EncryptionSDKClient(commitment_policy=CommitmentPolicy.REQUIRE_ENCRYPT_REQUIRE_DECRYPT)

    # Create an AWS KMS master key provider
    kms_kwargs = dict(key_ids=[key_arn])
    if botocore_session is not None:
        kms_kwargs["botocore_session"] = botocore_session
    master_key_provider = aws_encryption_sdk.StrictAwsKmsMasterKeyProvider(**kms_kwargs)

    # Encrypt the plaintext source data
    ciphertext, encryptor_header = client.encrypt(source=source_plaintext, key_provider=master_key_provider)
    return ciphertext

def lambda_handler(event, context):
    kmsclient = boto3.client('kms')
    #Get the kms key ARN from secret manager
    keyArn=json.loads(get_secret(keySecretName))['DocDBDemoKeyArn']
    person_data=json.loads(json.dumps(PERSON_DATA))
    for person in person_data:
        hashedPI = hashlib.sha256(person["personIdentifier"].encode()).hexdigest()
        encryptedPI=encryptString(keyArn, base64.b64encode(bytes(person["personIdentifier"], 'utf-8')))
        person["hashedPI"]=hashedPI[:8] # Will truncate the hash for additional security. 
        person["personIdentifier"]=encryptedPI

    insurance_data=json.loads(json.dumps(INSURANCE_DATA))
    for insurance in insurance_data:
        hashedPI = hashlib.sha256(insurance["personIdentifier"].encode()).hexdigest()
        encryptedPI=encryptString(keyArn, base64.b64encode(bytes(insurance["personIdentifier"], 'utf-8')))
        insurance["hashedPI"]=hashedPI[:8]
        insurance["personIdentifier"]=encryptedPI
        
    #Get the DocumentDB credentials from SecretManager
    credentials=json.loads(get_secret(dbSecretName))
    username = credentials['username']
    password = credentials['password']
    clusterendpoint = credentials['host']+":"+str(credentials['port'])
    print("connecting to database")
    client = pymongo.MongoClient(clusterendpoint, username=username, password=password, tls='true', tlsCAFile='/tmp/rds-combined-ca-bundle.pem', retryWrites='false')
    db = client.sample_database
    profiledata = db['profiledata']
    insurancedata = db['insurancedata']

    #Insert data
    profiledata.insert_many(person_data)
    insurancedata.insert_many(insurance_data)
    print("Successfully inserted data")
    #Clean up
    client.close()
    return {
        'statusCode': 200,
        'body': "Successfully inserted data"
    }

def get_secret(secret_name):
    region_name = "us-east-1"
 
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
 
    # We rethrow the exception by default.
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except Exception as e:
            raise e
 
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    return get_secret_value_response['SecretString']
